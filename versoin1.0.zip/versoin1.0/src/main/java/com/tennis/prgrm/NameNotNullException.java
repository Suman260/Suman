package com.tennis.prgrm;

public class NameNotNullException
  extends RuntimeException
{
  private static final long serialVersionUID = 1L;
  
  public NameNotNullException(String s)
  {
    super(s);
  }
}
