package com.tennis.prgrm;

public class Player
{
  private String name;
  private static final String[] Tscore = { "LOVE", "FIFTEEN", "THIRTY", "FORTY" };
  private int score;
  
  Player(String name1)
    throws NameNotNullException
  {
    if (name1 == null) {
      throw new NameNotNullException("Invalid name, Name cannot be null");
    }
    if (name1.trim().length() == 0) {
      throw new NameNotNullException("Invalid name, Name cannot be Empty or whitespace");
    }
    String name2 = name1.trim().replaceAll("\\s", "");
    this.name = name2;
  }
  
  public String getName()
  {
    return this.name;
  }
  
  public int getScore()
  {
    return this.score;
  }
  
  public void setScore(int score)
  {
    this.score = score;
  }
  
  public String scoreDesc(int score)
  {
    return Tscore[score];
  }
}
