package com.tennis.prgrm;

import java.util.Scanner;

public class TennisGame
{
  private Player p1;
  private Player p2;
  private String score;
  private String validation;
  
  TennisGame(Player p1, Player p2)
  {
    if (p1.getName().equalsIgnoreCase(p2.getName()))
    {
      this.validation = "Please enter different names for players";
      System.out.println(this.validation);
    }
    else
    {
      this.p1 = p1;
      this.p2 = p2;
      System.out.println("Valid Player Names");
      System.out.println("Game starts");
      this.score = p1.scoreDesc(p1.getScore()) + " - " + p2.scoreDesc(p2.getScore());
      System.out.println(this.score);
    }
  }
  
  public void wonPoint(String s1)
  {
    String s = s1.trim().replaceAll("\\s", "");
    if (this.p1.getName().equalsIgnoreCase(s))
    {
      this.p1.setScore(this.p1.getScore() + 1);
      this.validation = "OK";
      setScore(this.p1.getScore(), this.p2.getScore());
    }
    else if (this.p2.getName().equalsIgnoreCase(s))
    {
      this.p2.setScore(this.p2.getScore() + 1);
      this.validation = "OK";
      setScore(this.p1.getScore(), this.p2.getScore());
    }
    else
    {
      this.validation = "Invalid player name";
      System.out.println(this.validation);
      System.out.println("Player names available are:");
      System.out.println("Player1: " + this.p1.getName());
      System.out.println("Player2: " + this.p2.getName());
    }
  }
  
  public String getValidation()
  {
    return this.validation;
  }
  
  public String getScore()
  {
    return this.score;
  }
  
  public void setScore(int s1, int s2)
  {
    if ((getLeadingPlayer().getScore() == 4) && (Math.abs(this.p1.getScore() - this.p2.getScore()) >= 2))
    {
      this.score = (getLeadingPlayer().getName() + " Won");
      System.out.println(this.score);
      System.out.println("Game ends");
      return;
    }
    if ((this.p1.getScore() >= 3) && (this.p2.getScore() >= 3))
    {
      if (Math.abs(this.p1.getScore() - this.p2.getScore()) >= 2)
      {
        this.score = (getLeadingPlayer().getName() + " Won");
        System.out.println(this.score);
        System.out.println("Game ends");
        return;
      }
      if (this.p1.getScore() == this.p2.getScore())
      {
        this.score = "Deuce";
        System.out.println(this.score);
      }
      else
      {
        this.score = ("Advantage " + getLeadingPlayer().getName());
        System.out.println(this.score);
      }
    }
    else
    {
      this.score = (this.p1.scoreDesc(s1) + " - " + this.p2.scoreDesc(s2));
      System.out.println(this.score);
    }
  }
  
  public Player getLeadingPlayer()
  {
    if (this.p1.getScore() > this.p2.getScore()) {
      return this.p1;
    }
    return this.p2;
  }
  
  public static void main(String[] args)
  {
    Scanner sc = new Scanner(System.in);
    String name1;
    String name2;
    do
    {
      System.out.println("Player Names cannot be same");
      System.out.println("Enter Player 1 name:");
      name1 = sc.nextLine().trim().replaceAll("\\s", "");
      System.out.println("Enter Player 2 name:");
      name2 = sc.nextLine().trim().replaceAll("\\s", "");
    } while ((name1.equalsIgnoreCase(name2)) && ((!name1.isEmpty()) || (!name2.isEmpty())));
    Player p1 = null;
    Player p2 = null;
    TennisGame t = null;
    try
    {
      p1 = new Player(name1);
      p2 = new Player(name2);
      t = new TennisGame(p1, p2);
      while (!t.getScore().contains("Won"))
      {
        System.out.println("Point won by:");
        String name3 = sc.nextLine();
        t.wonPoint(name3);
      }
    }
    catch (NameNotNullException e)
    {
      System.out.println(e);
      System.out.println("Program terminated due to bad input");
    }
    finally
    {
      sc.close();
    }
  }
}
