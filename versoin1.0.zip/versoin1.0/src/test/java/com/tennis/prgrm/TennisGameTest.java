package com.tennis.prgrm;

import org.junit.Assert;
import org.junit.Before;
import org.junit.Test;

public class TennisGameTest
{
  Player p1,p2;
  TennisGame g;
  
  @Before
  public void before()
  {
    this.p1 = new Player("Player1");
    this.p2 = new Player("Player2");
    this.g = new TennisGame(this.p1, this.p2);
  }
  
  @Test
  public void testStringDescScore0()
  {
    Assert.assertEquals("LOVE - LOVE", this.g.getScore());
  }
  
  @Test
  public void testStringDescScore1()
  {
    this.g.wonPoint("Player1");
    Assert.assertEquals("FIFTEEN - LOVE", this.g.getScore());
  }
  
  @Test
  public void testStringDescScore2()
  {
    this.g.wonPoint("Player1");
    this.g.wonPoint("Player1");
    this.g.wonPoint("Player2");
    Assert.assertEquals("THIRTY - FIFTEEN", this.g.getScore());
  }
  
  @Test
  public void testStringDescScore3()
  {
    this.g.wonPoint("Pla  yer1");
    this.g.wonPoint("  player1");
    this.g.wonPoint("player1  ");
    this.g.wonPoint("Play  er2");
    this.g.wonPoint("Player2");
    Assert.assertEquals("FORTY - THIRTY", this.g.getScore());
  }
  
  @Test
  public void testPlayer1won()
  {
    for (int i = 1; i <= 3; i++) {
      this.g.wonPoint("Player1");
    }
    this.g.wonPoint("Player2");
    this.g.wonPoint("Player2");
    this.g.wonPoint("Player1");
    Assert.assertEquals("Player1 Won", this.g.getScore());
    Assert.assertNotEquals("Player2 Won", this.g.getScore());
  }
  
  @Test
  public void testPlayer2won()
  {
    for (int i = 1; i <= 3; i++) {
      this.g.wonPoint("Player2");
    }
    this.g.wonPoint("Player1");
    this.g.wonPoint("Player2");
    Assert.assertEquals("Player2 Won", this.g.getScore());
  }
  
  @Test
  public void testDeuceCondition()
  {
    for (int i = 1; i <= 3; i++) {
      this.g.wonPoint("Player1");
    }
    for (int i = 1; i <= 3; i++) {
      this.g.wonPoint("Player2");
    }
    Assert.assertEquals("Deuce", this.g.getScore());
    this.g.wonPoint("Player1");
    Assert.assertNotEquals("Deuce", this.g.getScore());
    this.g.wonPoint("Player2");
    Assert.assertEquals("Deuce", this.g.getScore());
  }
  
  @Test
  public void testAdvantageCondition()
  {
    for (int i = 1; i <= 3; i++) {
      this.g.wonPoint("Player1");
    }
    for (int i = 1; i <= 3; i++) {
      this.g.wonPoint("Player2");
    }
    this.g.wonPoint("Player1");
    Assert.assertEquals("Advantage Player1", this.g.getScore());
    this.g.wonPoint("Player2");
    Assert.assertNotEquals("Advantage Player1", this.g.getScore());
    this.g.wonPoint("Player2");
    Assert.assertEquals("Advantage Player2", this.g.getScore());
  }
  
  @Test
  public void testPlayer1WonWithAdv()
  {
    for (int i = 1; i <= 3; i++) {
      this.g.wonPoint("Player1");
    }
    for (int i = 1; i <= 3; i++) {
      this.g.wonPoint("Player2");
    }
    Assert.assertEquals("Deuce", this.g.getScore());
    this.g.wonPoint("Player1");
    Assert.assertEquals("Advantage Player1", this.g.getScore());
    Assert.assertNotEquals("Advantage Player2", this.g.getScore());
    this.g.wonPoint("Player1");
    Assert.assertEquals("Player1 Won", this.g.getScore());
    Assert.assertNotEquals("Player2 Won", this.g.getScore());
  }
  
  @Test
  public void testValidatePlayername()
  {
    this.g.wonPoint("wrong name");
    Assert.assertEquals("Invalid player name", this.g.getValidation());
    this.g.wonPoint("player1");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint("player2");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint(" player1");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint("player2 ");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint("pla  yer2  ");
    Assert.assertEquals("OK", this.g.getValidation());
  }
  
  @Test
  public void testFromPlayerclass()
  {
    this.p1 = new Player("  Player1");
    this.p2 = new Player("Player2  ");
    this.g = new TennisGame(this.p1, this.p2);
    this.g.wonPoint(" Player1");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint("Player2 ");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint(" player1");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint("player2 ");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint("Player 1");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint("Playe   r2");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint("player     1");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint("pla  yer       2");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint("        pla        yer       1");
    Assert.assertEquals("OK", this.g.getValidation());
    this.g.wonPoint("      //  pla          yer            2");
    Assert.assertEquals("Invalid player name", this.g.getValidation());
  }
  
  @Test
  public void testSameAndEmptyNames()
  {
    this.p1 = new Player("Player1");
    this.p2 = new Player(" player1");
    this.g = new TennisGame(this.p1, this.p2);
    Assert.assertEquals("Please enter different names for players", this.g.getValidation());
  }
  
  @Test(expected=NameNotNullException.class)
  public void testNullName1()
  {
    this.p1 = new Player("Player1");
    this.p2 = new Player(null);
  }
  
  @Test(expected=NameNotNullException.class)
  public void testNullName2()
  {
    this.p1 = new Player(null);
    this.p2 = new Player("Player2");
  }
  
  @Test(expected=NameNotNullException.class)
  public void testEmptyname()
  {
    this.p1 = new Player("");
    this.p2 = new Player("Player2");
  }
  
  @Test(expected=NameNotNullException.class)
  public void testWhiteCharactername()
  {
    this.p1 = new Player("Player1");
    this.p2 = new Player("     ");
  }
  
  @Test(expected=NameNotNullException.class)
  public void testTwoWhitespacesofsameLenght()
  {
    this.p1 = new Player("     ");
    this.p2 = new Player("     ");
  }
 
}
